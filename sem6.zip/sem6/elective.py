def ml():
    print("Machine lerning")
