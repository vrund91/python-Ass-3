def dt():
    print("Data Techniques")

def drupal():
    print("Drupal is good")