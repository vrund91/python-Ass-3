def python():
    print("python is good language")

def infosec():
    print("information security")

def se():
    print("se")

def ai():
    print("Artificial intelligence")