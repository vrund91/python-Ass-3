from .core import python,infosec,se,ai
from .ae import drupal,dt
from .elective import ml