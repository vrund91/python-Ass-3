def potato():
    print("potato is not king of vegetable")

def tomato():
    print("Tomato has vitamin c")