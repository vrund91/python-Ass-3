def apple():
    print("apple is red")

def banana():
    print("Banana is yellow")

def orange():
    print("orange is a good fruit")